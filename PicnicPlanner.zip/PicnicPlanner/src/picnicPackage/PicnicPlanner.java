package picnicPackage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PicnicPlanner extends PicnicItemStore {

private List<String> plan = new ArrayList<String>();
private PicnicItemStore picnicitemstore;
private CheeseStore cheesestore;
private DrinkStore drinkstore;
private int prefix;

    public PicnicPlanner() throws IOException {
        //constructor for q2 which doesnt take a prefix and constructs a basic map with the respective items
        this.picnicitemstore= new PicnicItemStore("fruits.txt");
        drinkstore = new DrinkStore("drinks.txt");
        cheesestore = new CheeseStore("cheeses.txt");
        
        
        this.plan = plan;
        //when no prefix is passed, prefix can be recalled as 0
        this.prefix = 0;
    }
    
    public PicnicPlanner(int prefix) throws IOException {
        //constructor which takes prefix and builds 3 stores with their respective items 
        this.prefix = prefix;
          this.picnicitemstore = picnicitemstore = new PicnicItemStore("fruits.txt", prefix);
         this.drinkstore = drinkstore = new DrinkStore("drinks.txt", prefix);
        this.cheesestore = cheesestore = new CheeseStore("cheeses.txt", prefix);
        
        this.plan = plan;
    }
    
    public List<String> generate(String input) throws IOException {

        int itemcount = input.length();
        int curamount = 0;
    
    
        String item;    
        //iterates through the input length (through each character (unless prefix is provided))
            for (curamount = 0; curamount < itemcount ; curamount++) {
                int j = curamount % 3;
                //modulus 3 as there are 3 cases (fruits, cheeses and drinks)
                 char ch;
                 String key = "";
                
                if (j == 0) {
                    //if j=0 then a fruit is being added
                    int pref = this.prefix;
                    if (pref == 0 || curamount == input.length()-1) {
                        /*if no prefix was entered in the args or the program is processing the last letter
                        *then call a basic key build with just the current character (the first character)
                        */ 
                         ch = input.charAt(curamount);
                         key = String.valueOf(ch);
                         
                         } else {
                             
                            while (pref > 0) {
                                //while the prefix is above 0 loop
                                if (input.substring(curamount,input.length()).length() <= pref) {
                                    /*this checks that if the length of the input excluding the items already added
                                    *is above the preference then it reduces the prefix, this ensures the key will always be built
                                     *without errors for example StringIndexOutofBounds
                                    */
                                    pref--;
                                    continue;
                                }
                                /*builds a key by eliminating the previously added items by using a substring on a substring
                                 *where the first substring is the current list excluding the previously added items
                                * and the second substring is the first letter to the  prefix inputted
                                */
                                key = input.substring(curamount, input.length()).substring(0, pref);
                             if (this.picnicitemstore.containsKey(key) == true) {
                                 //if the key is found then add the amount of items added by checking the key length
                                 curamount += key.length() - 1;
                                 break;
                                 //if key is found break out the loop and continue with adding the value of the key
                             } else {
                                 /*else pref is decremented.. eventually if pref = 1 then the key will always be found 
                                 *and curamount will be incremented by at least 1
                                 */
                                 pref--;
                                 continue; 
                             }   
                         }
                         }
                    
                    item = this.picnicitemstore.getRandomItem(key);
                    //return the value of the key from the cheesestore and store it as the item
                    item = item.substring(0, key.length()).toUpperCase() + item.substring(key.length());
                    //this capitalises just the amount of letters that were used (the amount of items added)
                    this.plan.add(item + "\n");
                    System.out.println(item);
                    //adds and prints the item with a new line character trailing
                     if (curamount == itemcount) {
                         break;
                         //if the string reaches the end then it should end
                     }
                } 
                if (j == 1) {
                    //if j=1 then a cheese is being added
                    int pref = this.prefix;
                    if (pref == 0 || curamount == input.length()-1) {
                        /*if no prefix was entered in the args or the program is processing the last letter
                        *then call a basic key build with just the current character (the first character)
                        */ 
                         ch = input.charAt(curamount);
                         key = String.valueOf(ch);
                         
                         } else {
                             
                            while (pref > 0) {
                                //while the prefix is above 0 loop
                                if (input.substring(curamount,input.length()).length() <= pref) {
                                    /*this checks that if the length of the input excluding the items already added
                                    *is above the preference then it reduces the preference, this ensures the key will always be built
                                     *without errors for example StringIndexOutofBounds
                                    */
                                    pref--;
                                    continue;
                                }
                                /*builds a key by eliminating the previously added items by using a substring on a substring
                                 *where the first substring is the current list excluding the previously added items
                                * and the second substring is the first letter to the  prefix inputted
                                */
                                key = input.substring(curamount, input.length()).substring(0, pref);
                             if (this.cheesestore.containsKey(key) == true) {
                                 //if the key is found then add the amount of items added by checking the key length
                                 curamount += key.length() - 1;
                                 break;
                                 //if key is found break out the loop and continue with adding the value of the key
                             } else {
                                 /*else pref is decremented.. eventually if pref = 1 then the key will always be found 
                                 *and curamount will be incremented by at least 1
                                 */
                                 pref--;
                                 continue; 
                             }   
                         }
                         }
                    
                    item = this.cheesestore.getRandomItem(key);
                    //return the value of the key from the fruitstore and store it as the item
                    item = item.substring(0, key.length()).toUpperCase() + item.substring(key.length());
                    //this capitalises just the amount of letters that were used (the amount of items added)
                    this.plan.add(item + "\n");
                    System.out.println(item);
                    //adds and prints the item with a new line character trailing
                     if (curamount == itemcount) {
                         break;
                         //if the string reaches the end then it should end
                     }
                } 
                if (j == 2) {
                    //if j=0 then a fruit is being added
                    int pref = this.prefix;
                    if (pref == 0 || curamount == input.length()-1) {
                        /*if no prefix was entered in the args or the program is processing the last letter
                        *then call a basic key build with just the current character (the first character)
                        */ 
                         ch = input.charAt(curamount);
                         key = String.valueOf(ch);
                         
                         } else {
                             
                            while (pref > 0) {
                                //while the prefix is above 0 loop
                                if (input.substring(curamount,input.length()).length() <= pref) {
                                    /*this checks that if the length of the input excluding the items already added
                                    *is above the preference then it reduces the preference, this ensures the key will always be built
                                     *without errors for example StringIndexOutofBounds
                                    */
                                    pref--;
                                    continue;
                                }
                                /*builds a key by eliminating the previously added items by using a substring on a substring
                                 *where the first substring is the current list excluding the previously added items
                                * and the second substring is the first letter to the  prefix inputted
                                */
                                key = input.substring(curamount, input.length()).substring(0, pref);
                             if (this.drinkstore.containsKey(key) == true) {
                                 //if the key is found then add the amount of items added by checking the key length
                                 curamount += key.length() - 1;
                                 break;
                                 //if key is found break out the loop and continue with adding the value of the key
                             } else {
                                 /*else pref is decremented.. eventually if pref = 1 then the key will always be found 
                                 *and curamount will be incremented by at least 1
                                 */
                                 pref--;
                                 continue; 
                             }   
                         }
                         }
                    
                    item = this.drinkstore.getRandomItem(key);
                    //return the value of the key from the drinkstore and store it as the item
                    item = item.substring(0, key.length()).toUpperCase() + item.substring(key.length());
                    //this capitalises just the amount of letters that were used (the amount of items added)
                    this.plan.add(item + "\n");
                    System.out.println(item);
                    //adds and prints the item with a new line character trailing
                     if (curamount == itemcount) {
                         break;
                         //if the string reaches the end then it should end
                     }
                }
                }
    
             return this.plan;
}
        

        public static void main(String[] args) throws IOException  {
            //it throws IOException because of the file handling
            //if they actually input arguments  
            if (args.length != 0) {
                String arg = args[0];
                arg = arg.toLowerCase();
                //as all keys and inputs are registered as lower case we call lowercase here
                for (int i = 0; i < arg.length(); i++) { 
                    //iterates through the name length they input
                    boolean isLetter = Character.isLetter(arg.toCharArray()[i]);
                    //converts the name argument to a char array so it can be iterated 
                    //through and checks if the input is a valid character
                    if (isLetter) {
                        break;
                    } else {
                        //if not it enters a error message and exits the system
                        System.err.println("Please only enter valid characters [no numbers or special characters]");
                        System.exit(0);
                }
                
                
                }
                if (args.length == 1) {
                    //if there is only the name with no prefix it calls the constructor that affectcs them
                    PicnicPlanner picnic = new PicnicPlanner();
                    picnic.generate(arg);
                } else {
                    String prefixarg = args[1];
                    int prefix;
                    for (int i = 0; i < prefixarg.length(); i++) { 
                        //checks if the prefix is a valid number
                        boolean isLetter = Character.isDigit(prefixarg.toCharArray()[i]);

                        if (isLetter) {
                            break;
                        } else {
                            //if not then we print an error message and exit the system
                            System.err.println("Please only enter valid characters [no numbers or special characters]");
                            System.exit(0);
                    }
                    }
                
                    //converts the prefix argument to an integer from a string
                        prefix = Integer.parseInt(prefixarg);
                
                if (prefix >0) {
                    //if prefix is bigger then we can construct a valid PicnicPlanner
                    PicnicPlanner picnic = new PicnicPlanner(prefix);
                    picnic.generate(arg);
            } else {
                //checks if they put 0 or negative prefixes and prints off an error message and exits

                System.err.println("prefix has to be at least 1");
                System.exit(0);
            }
          
                }
        
    } else {
        System.out.println("Please only enter valid characters [no numbers or special characters]");
    }
        }
}

        
