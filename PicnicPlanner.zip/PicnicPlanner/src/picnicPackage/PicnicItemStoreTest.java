package picnicPackage;
import java.io.IOException;

public class PicnicItemStoreTest extends PicnicItemStore {
    public static void main (String[] args) throws IOException {
        PicnicItemStore store = new PicnicItemStore(); 
        store.put("a", "abiu");
        store.put("bl", "blackberry");
        store.put("bl", "blackcurrent");
        store.put("a", "apricot");
        System.out.println(store.getRandomItem("a"));
        
        System.out.println(store.containsKey(null));
        
        PicnicItemStore store2 = new PicnicItemStore("fruits.txt");
        System.out.println(store2.getRandomItem("A"));
        CheeseStore store3 = new CheeseStore("cheeses.txt");
        System.out.println(store3.getRandomItem("O"));
        DrinkStore store4 = new DrinkStore("drinks.txt");
        System.out.println(store4.getRandomItem("O"));
         PicnicPlanner picnic = new PicnicPlanner(3);
         System.out.println(picnic.generate("dominique"));
         PicnicPlanner picnicsameprefix = new PicnicPlanner(9);
         System.out.println(picnicsameprefix.generate("dominique")); 
         
    }
}
