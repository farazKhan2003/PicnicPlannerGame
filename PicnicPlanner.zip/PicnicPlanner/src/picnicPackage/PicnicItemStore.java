package picnicPackage;
import java.util.List;
import java.util.Map;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class PicnicItemStore {
    protected Map<String, List<String>> map;
    //maps scope is protected not private as we need to access them other times
     
     public PicnicItemStore() {
          this.map = new HashMap<>();
          //creates a hashmap
          
     }
     public void put(String key, String value) { 
         //the put method adds a key to a value
         if (this.map.get(key) == null) {
             //if the key doesnt already exist add it to an empty arraylist
             this.map.put(key,  new ArrayList<String>());
         }
         this.map.get(key).add(value);
     }
     
     public PicnicItemStore(String filename) throws IOException {
         //constructor that takes a filename
         map = new HashMap<>();
         BufferedReader reader = new BufferedReader(new FileReader(filename));
         //creates a buffered reader to read chunks of the file at a time as its quicker
         //and more efficient than a regular filereader due to the stores sizes'
         
         try {
             String CurRead;
             String Value = "";
            
             while ((CurRead = reader.readLine()) != null) {
         //while there is another line to read in the file
                  CurRead = CurRead.toLowerCase();
                  //converts to lowercase
                  Value = CurRead;
                  if (map.get(CurRead.substring(0, 1)) == null) {
                      //create a key value to the lists 
                         map.put(CurRead.substring(0, 1).toLowerCase(),  new ArrayList<String>());
                     }
                     map.get(CurRead.substring(0, 1)).add(Value);                
             }
     } finally {
         reader.close();
         //flush the reader from the file
     }
     }
     public PicnicItemStore(String filename, int prefix) throws IOException {
         this.map = new HashMap<>();
         BufferedReader reader = new BufferedReader(new FileReader(filename));
         try {
             String CurRead;
             String Value = "";
             int curreadsize;
            
             while ((CurRead = reader.readLine()) != null) {
                 for (int i = 1; i < prefix+1; i++) {
                     //runs a for loop to add each letter sequence as a key to the same value
                  CurRead = CurRead.toLowerCase();
                  curreadsize = CurRead.length();
                  if (i > curreadsize) {
                      //if the prefix is bigger than the item it can move on
                      break;
                  }
                  //if CurRead.substring(0,i) doesnt exist in CurRead then moveon
                String key = CurRead.substring(0,i);
                  Value = CurRead;
                  if (this.map.get(key) == null) {
                        this. map.put(key, new ArrayList<String>());
                     }
                     this.map.get(key).add(Value);  
                    
                 }
                 
                 
             }
     } finally {
         reader.close();
     }
     }
     
    
     
     public boolean containsKey(String key) {
         //if the map doesnt contain the key contain false, if it does return true
        if (!this.map.containsKey(key)) {
         return false;
         } else {
             return true;
         }
    
     }
     
     
     
     public String getRandomItem(String key) {
         key = key.toLowerCase();
        //takes in key and generates a random value for that key
         if (!map.containsKey(key)) {
             return null;
         } else { 
         Random random = new Random();
        List<String> ranList = map.get(key);
        String randomString = ranList.get(random.nextInt(ranList.size()));
        String s1 = "";
        s1 = randomString.substring(0, 1).toUpperCase() + randomString.substring(1);
         
         
         
         return s1;
     }
     }
    
}
